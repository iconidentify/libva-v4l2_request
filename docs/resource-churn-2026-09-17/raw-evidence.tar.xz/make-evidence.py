"""Audit completed #41 evidence before publishing it; never opens the decoder."""
import hashlib
import io
import json
from pathlib import Path
import re
import subprocess
import sys
import tarfile

ROOT = Path(__file__).resolve().parent
REPO = ROOT / 'driver'
DEST = REPO / 'docs/resource-churn-2026-09-17'
BASE = '299d29333bc215d9d045130a0e0c6b8558a6654a'
DRIVER = 'ce5c4513e72d1178f3bcb695f8acd76ad298564df8077eb408722cc447fb6f63'
LIMITS = {'fds': 0, 'maps': 0, 'mapped_bytes': 4194304, 'vmrss_kib': 4096,
          'dmabuf_references': 0, 'dmabuf_objects': 0, 'dmabuf_bytes': 0,
          'heap_allocated_bytes': 65536}


def sha(data):
    return hashlib.sha256(data).hexdigest()


def rows(path):
    return [json.loads(line) for line in path.read_text().splitlines()]


def git(*args):
    return subprocess.check_output(['git', *args], cwd=REPO).decode().strip()


def guarded(name):
    records = rows(ROOT / (name + '-guard.jsonl'))
    first, last = records[0], records[-1]
    assert first['event'] == 'preflight' and first['idle'] and first['module_loaded']
    # hwguard records checkout HEAD; the campaign records the selected binary's
    # build revision. #81 changed only unrelated probe/evidence files between
    # stages. Verify equivalence instead of relabeling either raw provenance.
    checkout = first['userspace']['source_commit']
    identity = json.loads((ROOT / 'campaign-identity.json').read_text())
    assert checkout in (BASE, identity['publication_base'])
    assert git('diff', BASE, checkout, '--', 'src', *identity['source_hashes']) == ''
    assert last['event'] == 'final' and last['status'] == 'ok' and last['returncode'] == 0
    assert last['idle'] and not last['holders'] and not last['timed_out']
    assert not last['wedged'] and not last['abort_reason']
    assert {r['event'] for r in records} == {'preflight', 'start', 'final'}
    assert len({r['run_id'] for r in records}) == 1
    return records


def manifest():
    result = json.loads((ROOT / 'media/inputs.json').read_text())
    assert len(result['inputs']) == 4
    for item in result['inputs']:
        assert sha((ROOT / 'media' / item['name']).read_bytes()) == item['sha256']
        assert len(item['frames']) == 24
        reference = (ROOT / 'media' / (item['name'] + '.reference')).read_text().splitlines()
        assert [line for line in reference if line.startswith('frame ')] == item['frames']
        assert [line for line in reference if line.startswith('MD5=')] == ['MD5=' + item['md5']]
    for file, key in [('workload', 'workload_sha256'), ('early.so', 'early_export_sha256')]:
        assert sha((ROOT / 'media' / file).read_bytes()) == result[key]
    for file, key in [('resource-workload.c', 'workload_source_sha256'),
                      ('frame-check.c', 'reference_source_sha256')]:
        assert sha((REPO / 'tests' / file).read_bytes()) == result[key]
    return result


def audit_run(name, inputs):
    data = rows(ROOT / (name + '.jsonl'))
    meta, end = data[0], data[-1]
    assert meta['type'] == 'metadata' and end['type'] == 'summary'
    assert end['passed'] and end['returncode'] == 0 and not end['violations']
    expected_limits = dict(LIMITS, mapped_bytes=0) if name == 'post-interrupt' else LIMITS
    assert meta['limits'] == end['limits'] == expected_limits
    assert meta['source_commit'] == BASE and meta['driver_sha256'] == DRIVER
    assert meta['inputs_sha256'] == sha((ROOT / 'media/inputs.json').read_bytes())
    assert meta['warmup_cycles'] == end['warmup_cycles'] == 20
    assert meta['mode'] == end['mode'] == ('early' if name in ('early-1000', 'soak') else 'normal')
    samples = [r for r in data if r['type'] == 'sample']
    initial = [r for r in data if r['type'] == 'initial']
    assert len(initial) == 1 and len(data) == len(samples) + 3
    initial = initial[0]
    assert len(samples) == end['cycles'] + 1 == end['samples']
    assert [s['cycle'] for s in samples] == list(range(len(samples)))
    assert len({(s['pid'], s['process_start_time']) for s in samples + [initial]}) == 1
    assert all(a['monotonic_ns'] < b['monotonic_ns'] for a, b in zip(samples, samples[1:]))
    for metric in ('fd_count', 'dmabuf_references', 'dmabuf_objects', 'dmabuf_bytes'):
        assert initial[metric] is not None and all(s[metric] == initial[metric] for s in samples)
    baseline = samples[0]
    mapping = {'fd_count': 'fds', 'map_count': 'maps', 'mapped_bytes': 'mapped_bytes',
               'vmrss_kib': 'vmrss_kib', 'dmabuf_references': 'dmabuf_references',
               'dmabuf_objects': 'dmabuf_objects', 'dmabuf_bytes': 'dmabuf_bytes'}
    for sample in samples:
        assert sample['decoded_frames'] == (sample['cycle'] + 20) * 48
        assert sample['dmabuf']['status'] == 'none-observed'
        for metric, limit in mapping.items():
            assert sample[metric] - baseline[metric] <= expected_limits[limit]
        old, new = baseline['allocator'], sample['allocator']
        assert new['allocated'] + new['mmap'] - old['allocated'] - old['mmap'] <= 65536
        arena_growth = max(0, new['arena'] - old['arena']) + max(0, new['mmap'] - old['mmap'])
        assert sample['mapped_bytes'] - baseline['mapped_bytes'] <= arena_growth
    span = (samples[-1]['monotonic_ns'] - baseline['monotonic_ns']) / 1e9
    assert span == end['sample_span_seconds']
    if name == 'soak':
        assert span >= 3600 and meta['requested_seconds'] == 3600 and end['cycles'] >= 1000
    else:
        assert end['cycles'] == meta['requested_cycles'] == (4 if name == 'post-interrupt' else 1000)
        assert meta['requested_seconds'] == 0

    # Independently replay complete raw output, not just its success summary.
    count, pending, held, checkpoints = 0, [], 0, []
    with (ROOT / (name + '.workload.log')).open() as file:
        for raw in file:
            line = raw.rstrip('\n')
            if line.startswith('frame '):
                pending.append(line)
            elif line.startswith('RESULT '):
                match = re.fullmatch(r'RESULT cycle=(\d+) stream=(\d+) pass=(\d+) frames=(\d+) MD5=([0-9a-f]{32})', line)
                assert match
                cycle, stream, part, frames = map(int, match.groups()[:4])
                assert (cycle, stream, part) == (count // 2 + 1, count // 2 % 4, count % 2)
                reference = inputs['inputs'][stream]
                assert pending == reference['frames'] and frames == len(pending) == 24
                assert match[5] == reference['md5']
                count += 1
                pending = []
            elif line.startswith('HELD_IMAGE_PASS '):
                held += 1
                assert line == 'HELD_IMAGE_PASS cycle=%d' % held
            elif line.startswith('CHECKPOINT '):
                cycle = int(line.split()[1])
                assert not pending and count == (cycle + 20) * 2 and held == cycle + 20
                checkpoints.append(cycle)
    assert checkpoints == list(range(len(samples)))
    assert not pending and count == (end['cycles'] + 20) * 2
    assert count * 24 == end['decoded_frames'] and held == end['held_image_checks'] == end['cycles'] + 20
    early = 0
    with (ROOT / (name + '.stderr.log')).open() as file:
        for line in file:
            assert 'Failed to destroy' not in line and 'EARLY_EXPORT_FAIL' not in line
            early += line.startswith('EARLY_EXPORT_PASS:')
    assert early == (count * 24 if meta['mode'] == 'early' else 0)
    ranges = {key: {'baseline': baseline[key], 'minimum': min(s[key] for s in samples),
                    'maximum': max(s[key] for s in samples), 'final': samples[-1][key],
                    'peak_growth': max(s[key] for s in samples) - baseline[key],
                    'final_change': samples[-1][key] - baseline[key]} for key in mapping}
    allocated = [s['allocator']['allocated'] + s['allocator']['mmap'] for s in samples]
    ranges['allocator_accounted_bytes'] = {'baseline': allocated[0], 'minimum': min(allocated),
        'maximum': max(allocated), 'final': allocated[-1], 'peak_growth': max(allocated) - allocated[0],
        'final_change': allocated[-1] - allocated[0]}
    windows = [(a, min(b, end['cycles'])) for a, b in
               [(0, 100), (100, 500), (500, 1000), (1000, end['cycles'])] if a <= end['cycles']]
    return {'metadata': meta, 'summary': end, 'initial_display': initial, 'resource_ranges': ranges,
            'checkpoints': [s for s in samples if s['cycle'] in (0, 100, 500, 1000, end['cycles'])],
            'guard': guarded(name), 'raw_replay': {'matched_frame_records': count * 24,
            'held_image_records': held, 'early_export_identity_records': early},
            'allocator_windows': [{'cycle_from': a, 'cycle_to': b,
                                  'minimum': min(allocated[a:b + 1]),
                                  'maximum': max(allocated[a:b + 1])} for a, b in windows]}


def codec_results():
    assert 'ALL EXACT R11 PASS SETS MATCH' in (ROOT / 'codec-suites.log').read_text()
    baseline = json.loads((REPO / 'docs/r11-pass-sets.json').read_text())['suites']
    result = {}
    for name in ('hevc', 'avc', 'frext', 'vp9', 'vp9-high10', 'overrides'):
        path = ROOT / 'codec-suites'
        comp = json.loads((path / (name + '-comparison.json')).read_text())
        summary = json.loads((path / name / 'summary.json').read_text())
        records = [r for r in rows(path / name / 'results.jsonl') if r.get('event') == 'result']
        actual = {r['vector'] for r in records if r['success']}
        assert len(records) == summary['total'] and len({r['vector'] for r in records}) == len(records)
        assert actual == set(baseline[name]['passing_vectors'])
        assert not comp['lost'] and not comp['gained'] and summary['complete']
        assert comp['passed'] == len(actual) and comp['total'] == summary['total']
        result[name] = dict(comp, passing_frames=summary['passing_frames'],
                            high10=summary['high10'], profile_mismatch=summary['profile_mismatch'],
                            subset=summary['subset'])
        strict = path / (name + '-strict-comparison.json')
        if strict.exists():
            record = json.loads(strict.read_text())
            assert not any(record[k] for k in ('lost_passes', 'new_passes', 'missing_vectors', 'extra_vectors'))
            if name == 'avc':
                assert not record['ok'] and record['errors'] == ['software fallback cannot produce a green hardware result: FM1_FT_E']
            else:
                assert record['ok']
            result[name]['strict_comparison'] = record
    return result


def main():
    inputs = manifest()
    if len(sys.argv) == 3 and sys.argv[1] == '--audit-run':
        result = audit_run(sys.argv[2], inputs)
        print(json.dumps({k: result[k] for k in ('summary', 'resource_ranges', 'raw_replay')}, indent=2))
        return
    assert len(sys.argv) == 1
    results = {name: audit_run(name, inputs) for name in ('normal-1000', 'early-1000', 'soak', 'post-interrupt')}
    interrupted = rows(ROOT / 'interrupted.jsonl')[-1]
    assert interrupted['type'] == 'summary' and interrupted['passed'] is False
    interruption_records = rows(ROOT / 'interrupted.log')
    assert len(interruption_records) == 2
    interruption_log = interruption_records[0]
    assert interruption_log['interrupted_client'] == 'SIGKILL via bound pidfd'
    assert interruption_log['campaign_expected_failure'] is True
    assert interruption_log['coordinator_returncode'] != 0
    assert interruption_records[1]['status'] == 'ok' and interruption_records[1]['returncode'] == 0
    interruption_guard = guarded('interrupted')
    suites, codec_guard = codec_results(), guarded('codec')
    identity = json.loads((ROOT / 'campaign-identity.json').read_text())
    assert identity['tested_source_commit'] == BASE and identity['driver_sha256'] == DRIVER
    assert sha(Path(identity['driver_path']).read_bytes()) == DRIVER
    for name, expected in identity['source_hashes'].items():
        assert sha((REPO / name).read_bytes()) == expected
    assert git('rev-parse', 'HEAD:src') == git('rev-parse', BASE + ':src') == identity['production_src_tree']
    assert git('diff', BASE, '--', 'src', *identity['source_hashes']) == ''
    corpus = json.loads((ROOT / 'corpus-identities.json').read_text())
    corpus_count = 0
    for suite in corpus['suites']:
        for item in suite['inputs']:
            path = Path('<workspace>/src/fluster/resources') / suite['suite'] / item['vector'] / item['input_file']
            assert path.stat().st_size == item['bytes'] and sha(path.read_bytes()) == item['sha256']
            corpus_count += 1
    assert corpus_count == 662
    recovery = json.loads((ROOT / 'authorized-recovery.json').read_text())
    assert recovery['journal_since'] == '2026-09-17 02:16:40 UTC' and recovery['outcome']['healthy']
    report = {'issue': 'https://github.com/iconidentify/libva-v4l2_request/issues/41',
              'date': '2026-09-17', 'hardware_campaign_complete': True,
              'merge_acceptance': 'All hardware gates complete; final evidence integration is recorded in the linked PR and issue.',
              'review': 'Maintainer implementation and self-review; not independent review.',
              'identity': identity, 'recovery': recovery, 'inputs': inputs,
              'post_campaign_identity_checks': {'selected_driver_and_harness_unchanged': True,
                                                'pinned_corpus_input_hashes_rechecked': corpus_count},
              'acceptance_campaigns': results,
              'interrupted_client': {'summary': interrupted, 'log': interruption_records, 'guard': interruption_guard},
              'exact_codec_pass_sets': suites, 'codec_guard': codec_guard,
              'prior_failed_evidence': {
                  'first_soak_seconds': 616.048414118,
                  'second_soak_seconds': 1426.146430501,
                  'disposition': 'Both previous foreign-client-aborted soaks remain failed and separate; their durations are never combined with this campaign.',
                  'archive': '../resource-churn-2026-09-16/raw-evidence.tar.xz',
                  'report': '../resource-churn-validation-2026-09-16.json',
                  'merged_prs': [71, 76]},
              'limits': [
                  'One initialized VA display per campaign, four fixed synthetic 640x360 clips, 24 frames each; normal and early export decode/drain/seek/flush/redecode.',
                  'FD and dma-buf values must equal initial-display state at every checkpoint. Mapping/RSS/allocator growth is measured after 20 warmup lifecycles, using the unchanged reviewed limits.',
                  'Mapped/RSS values need not be flat: decreases are retained and peak positive growth is audited. Every positive mapped-byte change must be explained by allocator arena/mmap growth.',
                  'The 4 MiB mapped/RSS and 64 KiB allocated-byte bounds are workload-specific, not universal. mallinfo values include libc cache retention and are not driver ownership counters.',
                  'dma-buf none-observed means no process descriptors at quiescent checkpoints, not absence of global kernel allocations; unsampled descendants are not measured.',
                  'The intentional SIGKILL campaign remains a failed campaign by design; only its bounded cleanup, healthy outer guard and subsequent decode check pass. Process exit reclaim is not in-process ownership proof.',
                  'The pre-session firmware timeout remains unexplained. One existing-module reload was separately authorized and performed before all accepted tests; no automatic reset or journal-cutoff advancement occurred.',
                  'On-disk module provenance is recorded; the in-memory module hash is not measured.',
                  'Known failing codec vectors and the AVC non-green software-fallback verdict remain failures. Selected high-depth and profile-override subsets do not enlarge default support totals.',
                  'This selected userspace build is not installed. No package pin, kernel source, display/client configuration, support count or stability tier is changed.',
                  'No browser rendering, concurrent API calls, other dimensions, suspend/reboot or boot stability is qualified.']}
    names = {'campaign-identity.json', 'authorized-recovery.json', 'corpus-identities.json',
             'prepare.log', 'run-campaign.sh', 'codec-suites.py', 'make-evidence.py',
             'codec-suites.log', 'codec-guard.jsonl'}
    for name in ('normal-1000', 'early-1000', 'soak', 'interrupted', 'post-interrupt'):
        names.update(p.name for p in ROOT.glob(name + '*') if p.is_file() and p.suffix in ('.jsonl', '.log'))
    names.update(str(p.relative_to(ROOT)) for p in (ROOT / 'media').iterdir()
                 if p.suffix in ('.json', '.mkv', '.webm', '.reference'))
    names.update(str(p.relative_to(ROOT)) for p in (ROOT / 'codec-suites').rglob('*')
                 if p.is_file() and p.suffix in ('.json', '.jsonl', '.log', '.frames', '.sha256', '.stderr'))
    DEST.mkdir(exist_ok=False)
    members, archive = {}, DEST / 'raw-evidence.tar.xz'
    with tarfile.open(archive, 'w:xz', preset=6) as tar:
        for name in sorted(names):
            raw = (ROOT / name).read_bytes()
            public = raw if Path(name).suffix in ('.mkv', '.webm') else raw.replace(b'<workspace>', b'<workspace>')
            members[name] = {'raw_sha256': sha(raw), 'public_sha256': sha(public), 'bytes': len(public)}
            entry = tarfile.TarInfo(name)
            entry.size, entry.mtime, entry.mode = len(public), 1789603200, 0o644
            tar.addfile(entry, io.BytesIO(public))
    report['archive'] = {'path': 'raw-evidence.tar.xz', 'sha256': sha(archive.read_bytes()), 'members': len(members),
        'redaction': 'Only maintainer home-directory prefix replaced with <workspace> in public text; original and public hashes retained. Synthetic generated/pinned CC0 media included unchanged. No executable, external corpus media or core dump redistributed.'}
    (DEST / 'archive-manifest.json').write_text(json.dumps(members, indent=2) + '\n')
    (DEST / 'validation.json').write_text(json.dumps(report, indent=2).replace('<workspace>', '<workspace>') + '\n')
    with tarfile.open(archive, 'r:xz') as tar:
        assert len(tar.getmembers()) == len(members)
        for entry in tar:
            assert entry.isfile() and sha(tar.extractfile(entry).read()) == members[entry.name]['public_sha256']
    print(json.dumps({'archive_bytes': archive.stat().st_size, 'members': len(members),
                      'accepted_cycles': {name: r['summary']['cycles'] for name, r in results.items()}}))


if __name__ == '__main__':
    main()
