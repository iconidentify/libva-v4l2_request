#!/bin/bash
set -euo pipefail
campaign=<workspace>/validation41-20260917
cd "$campaign/driver"
export LIBVA_DRIVERS_PATH=<workspace>/validation79-20260917/driver/build-hardware/src
export LIBVA_DRIVER_NAME=v4l2_request
export V4L2R_SOURCE_COMMIT=299d29333bc215d9d045130a0e0c6b8558a6654a
boundary='2026-09-17 02:16:40 UTC'
python3 - <<'PY'
import hashlib,json
from pathlib import Path
import os
r=json.loads(Path('../authorized-recovery.json').read_text())
assert r['journal_since']=='2026-09-17 02:16:40 UTC' and r['outcome']['healthy']
assert hashlib.sha256((Path(os.environ['LIBVA_DRIVERS_PATH'])/'v4l2_request_drv_video.so').read_bytes()).hexdigest()=='ce5c4513e72d1178f3bcb695f8acd76ad298564df8077eb408722cc447fb6f63'
assert Path('../media/inputs.json').is_file()
for name in ('normal-1000','early-1000','soak','interrupted','post-interrupt','codec'):
    assert not Path('../'+name+'-guard.jsonl').exists(), 'fresh evidence paths required'
PY
for mode in normal early; do
    python3 tests/hwguard.py --identity avd --journal-since "$boundary" \
        --deadline 600 --log "$campaign/$mode-1000-guard.jsonl" -- \
        python3 tests/resource-campaign.py run --mode "$mode" --cycles 1000 \
        --max-mapped-growth-kib 4096 --directory "$campaign/media" \
        --output "$campaign/$mode-1000.jsonl" > "$campaign/$mode-1000.log" 2>&1
done
python3 tests/hwguard.py --identity avd --journal-since "$boundary" \
    --deadline 3900 --log "$campaign/soak-guard.jsonl" -- \
    python3 tests/resource-campaign.py run --mode early --cycles 1000000 --seconds 3600 \
    --max-mapped-growth-kib 4096 --directory "$campaign/media" \
    --output "$campaign/soak.jsonl" > "$campaign/soak.log" 2>&1
python3 - <<'PY'
import json
from pathlib import Path
r=json.loads(Path('../soak.jsonl').read_text().splitlines()[-1])
g=json.loads(Path('../soak-guard.jsonl').read_text().splitlines()[-1])
assert r['type']=='summary' and r['passed'] and r['sample_span_seconds']>=3600
assert g['status']=='ok' and g['idle'] and not g['abort_reason']
PY
python3 tests/hwguard.py --identity avd --journal-since "$boundary" \
    --deadline 60 --log "$campaign/interrupted-guard.jsonl" -- \
    python3 tests/resource-interrupt.py --directory "$campaign/media" \
    --output "$campaign/interrupted.jsonl" > "$campaign/interrupted.log" 2>&1
python3 tests/hwguard.py --identity avd --journal-since "$boundary" \
    --deadline 60 --log "$campaign/post-interrupt-guard.jsonl" -- \
    python3 tests/resource-campaign.py run --mode normal --cycles 4 \
    --directory "$campaign/media" --output "$campaign/post-interrupt.jsonl" \
    > "$campaign/post-interrupt.log" 2>&1
python3 tests/hwguard.py --identity avd --journal-since "$boundary" \
    --deadline 900 --log "$campaign/codec-guard.jsonl" -- \
    python3 "$campaign/codec-suites.py" > "$campaign/codec-suites.log" 2>&1
